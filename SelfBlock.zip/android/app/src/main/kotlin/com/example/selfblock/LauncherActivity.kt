package com.example.selfblock

import android.app.Activity
import android.graphics.Color
import android.graphics.ColorMatrix
import android.graphics.ColorMatrixColorFilter
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.*

/** 홈 화면 런처: 스케줄 중 허용되지 않은 앱은 회색 + 어둡게 표시, 누르면 실행 취소 */
class LauncherActivity : Activity() {
    private val h = Handler(Looper.getMainLooper())
    private val refresh = object : Runnable { override fun run() { render(); h.postDelayed(this, 30000) } }
    private lateinit var grid: GridView

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        grid = GridView(this).apply { numColumns = 4; verticalSpacing = 36; setPadding(16, 110, 16, 40); clipToPadding = false }
        setContentView(grid)
    }
    override fun onResume() { super.onResume(); h.post(refresh) }
    override fun onPause() { h.removeCallbacks(refresh); super.onPause() }
    override fun onBackPressed() {}   // 홈 화면에서는 뒤로 가기 무시

    private fun render() {
        val apps = Enforcer.launchable(this)
        val locked = apps.filter { Enforcer.shouldBlock(this, it.pkg) }.map { it.pkg }.toSet()
        val gray = ColorMatrixColorFilter(ColorMatrix().apply { setSaturation(0f) })
        grid.adapter = object : BaseAdapter() {
            override fun getCount() = apps.size
            override fun getItem(i: Int) = apps[i]
            override fun getItemId(i: Int) = i.toLong()
            override fun getView(i: Int, v: View?, p: ViewGroup?): View {
                val a = apps[i]; val off = a.pkg in locked
                return LinearLayout(this@LauncherActivity).apply {
                    orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
                    addView(ImageView(context).apply {
                        try { setImageDrawable(packageManager.getApplicationIcon(a.pkg)) } catch (_: Exception) {}
                        layoutParams = LinearLayout.LayoutParams(130, 130)
                        if (off) { colorFilter = gray; alpha = 0.35f }
                    })
                    addView(TextView(context).apply {
                        text = a.label; textSize = 11f; setTextColor(Color.WHITE); gravity = Gravity.CENTER; maxLines = 1
                        if (off) alpha = 0.4f
                    })
                    setOnClickListener {
                        if (off || Enforcer.shouldBlock(this@LauncherActivity, a.pkg))
                            Toast.makeText(context, "🔒 스케줄 실행 중\n앱 실행이 취소되었습니다", Toast.LENGTH_SHORT).show()
                        else packageManager.getLaunchIntentForPackage(a.pkg)?.let { startActivity(it) }
                    }
                }
            }
        }
    }
}
