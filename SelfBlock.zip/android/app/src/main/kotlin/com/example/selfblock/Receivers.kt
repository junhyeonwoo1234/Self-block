package com.example.selfblock

import android.app.admin.DeviceAdminReceiver
import android.content.*

class AdminReceiver : DeviceAdminReceiver()

class SyncReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) = Enforcer.sync(c)
}
