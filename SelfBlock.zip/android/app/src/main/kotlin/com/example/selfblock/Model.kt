package com.example.selfblock

import android.Manifest
import android.app.*
import android.app.admin.DevicePolicyManager
import android.content.*
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationManager
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

fun fmt(ms: Long): String = SimpleDateFormat("M/d HH:mm", Locale.KOREA).format(Date(ms))

/** days: Calendar.DAY_OF_WEEK(1=일..7=토), start/end: 분 (end<start면 자정 넘김), lat/lng: 장소 제한, delAt: 삭제 예약 시각 */
data class Sch(val days: Set<Int>, val start: Int, val end: Int, val allowed: Set<String>,
               val delAt: Long = 0, val lat: Double? = null, val lng: Double? = null) {
    fun activeAt(day: Int, min: Int): Boolean {
        val prev = if (day == 1) 7 else day - 1
        return if (end > start) day in days && min in start until end
        else (day in days && min >= start) || (prev in days && min < end)
    }
    fun label(): String {
        var t = "${"일월화수목금토".filterIndexed { i, _ -> (i + 1) in days }} " +
            "%02d:%02d~%02d:%02d · 허용앱 %d개".format(start / 60, start % 60, end / 60, end % 60, allowed.size)
        if (lat != null) t += " · 📍"
        if (delAt > 0) t += "\n⏳ 삭제 예약: ${fmt(delAt)}"
        return t
    }
}

data class Ev(val t: Long, val k: String, val v: String)   // k: B=차단 시도, U=관리자 해제

object Store {
    fun p(c: Context) = c.getSharedPreferences("s", 0)

    private fun parse(c: Context): MutableList<Sch> {
        val a = JSONArray(p(c).getString("list", "[]"))
        return MutableList(a.length()) {
            val o = a.getJSONObject(it)
            Sch(o.getJSONArray("d").let { x -> (0 until x.length()).map(x::getInt).toSet() },
                o.getInt("s"), o.getInt("e"),
                o.getJSONArray("a").let { x -> (0 until x.length()).map(x::getString).toSet() },
                o.optLong("x", 0), if (o.has("la")) o.getDouble("la") else null, if (o.has("ln")) o.getDouble("ln") else null)
        }
    }
    private fun write(c: Context, l: List<Sch>) {
        val a = JSONArray()
        l.forEach { s ->
            val o = JSONObject().put("d", JSONArray(s.days.toList())).put("s", s.start).put("e", s.end)
                .put("a", JSONArray(s.allowed.toList())).put("x", s.delAt)
            s.lat?.let { o.put("la", it) }; s.lng?.let { o.put("ln", it) }
            a.put(o)
        }
        p(c).edit().putString("list", a.toString()).apply()
    }
    /** 삭제 예약 시간이 지난 스케줄은 여기서 실제로 제거됨 */
    fun load(c: Context): MutableList<Sch> {
        val l = parse(c); val now = System.currentTimeMillis()
        val k = l.filter { it.delAt == 0L || it.delAt > now }.toMutableList()
        if (k.size != l.size) write(c, k)
        return k
    }
    fun save(c: Context, l: List<Sch>) { write(c, l); Enforcer.sync(c) }

    fun exc(c: Context): Set<String> = p(c).getStringSet("exc", emptySet())!!.toSet()
    fun setExc(c: Context, s: Set<String>) { p(c).edit().putStringSet("exc", s).apply(); Enforcer.sync(c) }

    /** 앱별 일일 한도: pkg -> (분, 삭제예약시각) */
    fun limits(c: Context): MutableMap<String, Pair<Int, Long>> {
        val o = JSONObject(p(c).getString("lim", "{}")); val now = System.currentTimeMillis()
        val m = mutableMapOf<String, Pair<Int, Long>>()
        o.keys().forEach { k -> val a = o.getJSONArray(k); if (!(a.getLong(1) in 1..now)) m[k] = Pair(a.getInt(0), a.getLong(1)) }
        if (m.size != o.length()) setLimits(c, m)
        return m
    }
    fun setLimits(c: Context, m: Map<String, Pair<Int, Long>>) {
        val o = JSONObject(); m.forEach { (k, v) -> o.put(k, JSONArray().put(v.first).put(v.second)) }
        p(c).edit().putString("lim", o.toString()).apply()
    }

    fun log(c: Context, k: String, v: String) {
        val a = JSONArray(p(c).getString("log", "[]")); a.put(JSONArray().put(System.currentTimeMillis()).put(k).put(v))
        val s = if (a.length() > 500) JSONArray((a.length() - 500 until a.length()).map { a.get(it) }) else a
        p(c).edit().putString("log", s.toString()).apply()
    }
    fun logs(c: Context): List<Ev> {
        val a = JSONArray(p(c).getString("log", "[]"))
        return (0 until a.length()).map { val r = a.getJSONArray(it); Ev(r.getLong(0), r.getString(1), r.getString(2)) }
    }
}

object Enforcer {

    fun dayKey(t: Long): String = Calendar.getInstance().apply { timeInMillis = t }
        .let { "%04d-%02d-%02d".format(it.get(Calendar.YEAR), it.get(Calendar.MONTH) + 1, it.get(Calendar.DAY_OF_MONTH)) }

    /** 관리자 해제와 무관한 "원래 스케줄" 상태 */
    fun scheduledNow(c: Context): Sch? {
        val n = Calendar.getInstance()
        if (dayKey(n.timeInMillis) in Store.exc(c)) return null
        val d = n.get(Calendar.DAY_OF_WEEK); val m = n.get(Calendar.HOUR_OF_DAY) * 60 + n.get(Calendar.MINUTE)
        return Store.load(c).firstOrNull { it.activeAt(d, m) && atPlace(c, it) }
    }
    fun active(c: Context): Sch? =
        if (System.currentTimeMillis() < Store.p(c).getLong("until", 0)) null else scheduledNow(c)

    // ---- 위치 ----
    fun lastLoc(c: Context): Location? {
        if (c.checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED) return null
        val lm = c.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return lm.getProviders(true).mapNotNull { try { lm.getLastKnownLocation(it) } catch (_: Exception) { null } }.maxByOrNull { it.time }
    }
    /** 위치를 알 수 없으면 '장소 안'으로 간주 (우회 방지) */
    private fun atPlace(c: Context, s: Sch): Boolean {
        val la = s.lat ?: return true; val ln = s.lng ?: return true
        val loc = lastLoc(c) ?: return true
        val r = FloatArray(1); Location.distanceBetween(la, ln, loc.latitude, loc.longitude, r)
        return r[0] <= 300
    }

    // ---- 앱별 일일 한도 ----
    fun hasUsage(c: Context): Boolean {
        val a = c.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        return a.unsafeCheckOpNoThrow(AppOpsManager.OPSTR_GET_USAGE_STATS, android.os.Process.myUid(), c.packageName) == AppOpsManager.MODE_ALLOWED
    }
    fun usedMin(c: Context, pkg: String): Long {
        val u = c.getSystemService(Context.USAGE_STATS_SERVICE) as android.app.usage.UsageStatsManager
        val st = Calendar.getInstance().apply { set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0) }.timeInMillis
        return (u.queryAndAggregateUsageStats(st, System.currentTimeMillis())[pkg]?.totalTimeInForeground ?: 0L) / 60000
    }
    fun overLimit(c: Context, pkg: String): Boolean {
        val l = Store.limits(c)[pkg] ?: return false
        return hasUsage(c) && usedMin(c, pkg) >= l.first
    }

    fun shouldBlock(c: Context, pkg: String): Boolean {
        if (pkg in always(c) || c.packageManager.getLaunchIntentForPackage(pkg) == null) return false
        val cur = active(c)
        if (cur != null && pkg !in cur.allowed) return true
        return overLimit(c, pkg)
    }

    // ---- 관리자 즉시 잠금 해제 ----
    fun adminUnlock(c: Context, ms: Long) {
        Store.p(c).edit().putLong("until", System.currentTimeMillis() + ms).apply()
        Store.log(c, "U", "관리자 해제"); sync(c)
    }
    fun relock(c: Context) { Store.p(c).edit().putLong("until", 0).apply(); sync(c) }

    // ---- 통계 ----
    fun appLabel(c: Context, pkg: String) = try {
        c.packageManager.getApplicationLabel(c.packageManager.getApplicationInfo(pkg, 0)).toString()
    } catch (_: Exception) { pkg }

    fun report(c: Context): String {
        val now = System.currentTimeMillis(); val all = Store.logs(c)
        val wk = all.filter { it.t >= now - 7 * 86400000L }; val b = wk.filter { it.k == "B" }
        val top = b.groupingBy { it.v }.eachCount().entries.sortedByDescending { it.value }.take(3)
            .joinToString { "${appLabel(c, it.key)} ${it.value}회" }
        val last = all.lastOrNull { it.k == "U" }?.t ?: Store.p(c).getLong("inst", now)
        return "📊 최근 7일\n차단 시도 ${b.size}회" + (if (top.isNotEmpty()) " ($top)" else "") +
            "\n관리자 해제 ${wk.count { it.k == "U" }}회\n🔥 관리자 해제 없이 ${(now - last) / 86400000L}일째"
    }

    // ---- 앱 목록 / 항상 허용 ----
    fun always(c: Context): Set<String> {
        val pm = c.packageManager
        val home = pm.resolveActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)?.activityInfo?.packageName
        val dial = pm.resolveActivity(Intent(Intent.ACTION_DIAL), 0)?.activityInfo?.packageName
        val set = pm.resolveActivity(Intent(android.provider.Settings.ACTION_SETTINGS), 0)?.activityInfo?.packageName
        val homes = pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0).map { it.activityInfo.packageName }
        return homes.toSet() + setOfNotNull(c.packageName, home, dial, set, "com.android.settings", "com.android.systemui", "com.android.phone")
    }
    data class ApplicationInfoLite(val pkg: String, val label: String)
    fun launchable(c: Context): List<ApplicationInfoLite> {
        val pm = c.packageManager
        return pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER), 0)
            .map { ApplicationInfoLite(it.activityInfo.packageName, it.loadLabel(pm).toString()) }
            .distinctBy { it.pkg }.sortedBy { it.label }
    }

    fun isAdmin(c: Context) = (c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager)
        .isAdminActive(ComponentName(c, AdminReceiver::class.java))
    fun isDefaultLauncher(c: Context) = c.packageManager.resolveActivity(
        Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)?.activityInfo?.packageName == c.packageName

    fun isOwner(c: Context) = (c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager).isDeviceOwnerApp(c.packageName)

    fun sync(c: Context) {
        val cur = active(c)
        if (isOwner(c)) {   // Family Link처럼 시스템이 앱을 회색 처리
            val dpm = c.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            val admin = ComponentName(c, AdminReceiver::class.java)
            val all = launchable(c).map { it.pkg }.toSet() - always(c)
            val over = Store.limits(c).keys.filter { overLimit(c, it) }.toSet()
            val block = (((if (cur == null) emptySet() else all - cur.allowed) + over) intersect all)
            try {
                dpm.setUninstallBlocked(admin, c.packageName, true)
                dpm.setPackagesSuspended(admin, (all - block).toTypedArray(), false)
                if (block.isNotEmpty()) dpm.setPackagesSuspended(admin, block.toTypedArray(), true)
            } catch (_: Exception) {}
        }
        notifyUpcoming(c); scheduleNext(c)
    }

    private fun at(off: Int, t: Int) = Calendar.getInstance().apply {
        add(Calendar.DAY_OF_YEAR, off); set(Calendar.HOUR_OF_DAY, t / 60); set(Calendar.MINUTE, t % 60)
        set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
    }.timeInMillis

    private fun upcomingStarts(c: Context): List<Long> = Store.load(c).flatMap { s ->
        (0..7).map { at(it, s.start) }.filter { x ->
            x > System.currentTimeMillis() && Calendar.getInstance().apply { timeInMillis = x }.get(Calendar.DAY_OF_WEEK) in s.days
        }
    }

    /** 시작 10분 전 알림 */
    private fun notifyUpcoming(c: Context) {
        val now = System.currentTimeMillis()
        val x = upcomingStarts(c).filter { it - now <= 11 * 60000L }.minOrNull() ?: return
        if (Store.p(c).getLong("notified", 0) == x) return
        Store.p(c).edit().putLong("notified", x).apply()
        val nm = c.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(NotificationChannel("n", "스케줄 알림", NotificationManager.IMPORTANCE_DEFAULT))
        nm.notify(1, Notification.Builder(c, "n").setSmallIcon(android.R.drawable.ic_lock_idle_lock)
            .setContentTitle("곧 스케줄이 시작돼요")
            .setContentText("${fmt(x)}부터 허용된 앱만 쓸 수 있어요. 마무리하세요!").build())
    }

    private fun scheduleNext(c: Context) {
        val now = System.currentTimeMillis()
        val cand = Store.load(c).flatMap { s ->
            (0..7).flatMap { o -> listOf(at(o, s.start), at(o, s.end), at(o, s.start) - 600000L) } + listOf(s.delAt)
        } + listOf(Store.p(c).getLong("until", 0)) + Store.limits(c).values.map { it.second }
        val best = cand.filter { it > now }.minOrNull() ?: return
        val pi = PendingIntent.getBroadcast(c, 0, Intent("com.example.selfblock.SYNC").setPackage(c.packageName),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        (c.getSystemService(Context.ALARM_SERVICE) as AlarmManager).setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, best, pi)
    }

    /** 관리자 패널에서만 호출: 보호 해제 후 삭제 화면으로 */
    fun uninstall(a: Activity) {
        Store.p(a).edit().putLong("uninstallOk", System.currentTimeMillis() + 60000).apply()
        if (isOwner(a)) {
            val dpm = a.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            val admin = ComponentName(a, AdminReceiver::class.java)
            try {
                dpm.setUninstallBlocked(admin, a.packageName, false)
                dpm.setPackagesSuspended(admin, launchable(a).map { it.pkg }.toTypedArray(), false)
                dpm.clearDeviceOwnerApp(a.packageName)
            } catch (_: Exception) {}
        } else {   // 일반 기기 관리자: 삭제 전에 먼저 해제해야 함
            val dpm = a.getSystemService(Context.DEVICE_POLICY_SERVICE) as DevicePolicyManager
            val admin = ComponentName(a, AdminReceiver::class.java)
            if (dpm.isAdminActive(admin)) try { dpm.removeActiveAdmin(admin) } catch (_: Exception) {}
        }
        android.os.Handler(android.os.Looper.getMainLooper()).postDelayed({
            a.startActivity(Intent(Intent.ACTION_DELETE, android.net.Uri.parse("package:" + a.packageName)))
        }, 800)
    }
}
