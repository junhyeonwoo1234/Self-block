package com.example.selfblock

import android.accessibilityservice.AccessibilityService
import android.content.*
import android.graphics.*
import android.location.LocationListener
import android.location.LocationManager
import android.os.Handler
import android.os.Looper
import android.view.*
import android.view.accessibility.AccessibilityEvent
import android.widget.TextView

class BlockService : AccessibilityService() {
    private val h = Handler(Looper.getMainLooper())
    private var overlay: View? = null
    private var last: String? = null

    private val unlock = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            Enforcer.sync(c)
            Enforcer.active(c)?.let { show("스케줄 실행 중\n${it.label()}") }
        }
    }
    /** 1분마다: 한도 초과/스케줄 시작 반영 + 위치 갱신 유지 */
    private val tick = object : Runnable {
        override fun run() {
            Enforcer.sync(this@BlockService)
            last?.let { if (Enforcer.shouldBlock(this@BlockService, it)) { Store.log(this@BlockService, "B", it); kick("사용 시간이 끝났어요") } }
            h.postDelayed(this, 60000)
        }
    }

    override fun onServiceConnected() {
        registerReceiver(unlock, IntentFilter(Intent.ACTION_USER_PRESENT))
        try {
            (getSystemService(LOCATION_SERVICE) as LocationManager)
                .requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 60000L, 50f, LocationListener { })
        } catch (_: Exception) {}
        h.post(tick)
    }

    private var lastGuard = 0L

    /** 화면에 '셀프블록' + 삭제 관련 글자가 같이 보이면(길게 누른 메뉴, 삭제 확인창, 앱 정보) 삭제 시도로 간주 */
    private fun deleting(): Boolean {
        val r = rootInActiveWindow ?: return false
        fun has(x: String) = r.findAccessibilityNodeInfosByText(x)?.isNotEmpty() == true
        return has("셀프블록") && (has("삭제") || has("제거") || has("Uninstall"))
    }

    override fun onAccessibilityEvent(e: AccessibilityEvent) {
        val pkg = e.packageName?.toString() ?: return
        if (pkg != packageName && Store.p(this).getLong("uninstallOk", 0) < System.currentTimeMillis() && deleting()) {
            val n = System.currentTimeMillis()
            if (n - lastGuard > 1500) { lastGuard = n; kick("삭제할 수 없습니다") }
            return
        }
        // 스케줄 중: 삭제 화면 / 접근성 설정 / 이 앱의 앱 정보 화면 차단
        if (Enforcer.active(this) != null && guarded(e, pkg)) { kick("스케줄 실행 중\n변경할 수 없습니다"); return }
        if (e.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        if (packageManager.getLaunchIntentForPackage(pkg) != null) last = pkg
        if (Enforcer.shouldBlock(this, pkg)) { Store.log(this, "B", pkg); kick("스케줄 실행 중\n앱 실행이 취소되었습니다") }
    }

    private fun guarded(e: AccessibilityEvent, pkg: String): Boolean {
        if (pkg.contains("packageinstaller")) return true
        if (!pkg.contains("settings")) return false
        val cn = e.className?.toString() ?: ""
        if (cn.contains("ccessibility") || cn.contains("DeviceAdmin") || cn.contains("HomeSettings")) return true
        return rootInActiveWindow?.findAccessibilityNodeInfosByText("셀프블록")?.isNotEmpty() == true
    }

    private fun kick(msg: String) { performGlobalAction(GLOBAL_ACTION_HOME); show(msg) }

    private fun show(msg: String) {
        val wm = getSystemService(WINDOW_SERVICE) as WindowManager
        overlay?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        val tv = TextView(this).apply {
            text = msg; textSize = 20f; setTextColor(Color.WHITE); gravity = Gravity.CENTER
            setPadding(60, 50, 60, 50); setBackgroundColor(Color.parseColor("#E6222222"))
        }
        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT, WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.CENTER }
        wm.addView(tv, lp); overlay = tv
        h.postDelayed({ try { wm.removeView(tv) } catch (_: Exception) {} }, 2500)
    }

    override fun onInterrupt() {}
    override fun onDestroy() {
        h.removeCallbacks(tick)
        try { unregisterReceiver(unlock) } catch (_: Exception) {}
        super.onDestroy()
    }
}
