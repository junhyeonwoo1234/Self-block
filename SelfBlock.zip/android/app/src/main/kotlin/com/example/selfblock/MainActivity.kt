package com.example.selfblock

import android.Manifest
import android.app.admin.DevicePolicyManager
import android.content.ComponentName
import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import org.json.JSONArray
import org.json.JSONObject

/** Flutter UI <-> 네이티브 차단 로직 연결 */
class MainActivity : FlutterActivity() {
    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        if (!Store.p(this).contains("inst")) Store.p(this).edit().putLong("inst", System.currentTimeMillis()).apply()
        requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS, Manifest.permission.ACCESS_FINE_LOCATION), 1)
    }

    override fun configureFlutterEngine(fe: FlutterEngine) {
        super.configureFlutterEngine(fe)
        MethodChannel(fe.dartExecutor.binaryMessenger, "selfblock").setMethodCallHandler { call, res ->
            try { res.success(handle(call)) } catch (e: Exception) { res.error("E", e.message, null) }
        }
    }

    private fun state(): String {
        val c = this; val cur = Enforcer.active(c)
        val sch = JSONArray(); Store.load(c).forEach { sch.put(JSONObject().put("label", it.label()).put("pending", it.delAt > 0)) }
        val lim = JSONArray()
        Store.limits(c).forEach { (k, v) ->
            lim.put(JSONObject().put("pkg", k).put("label", Enforcer.appLabel(c, k)).put("min", v.first).put("del", v.second)
                .put("used", if (Enforcer.hasUsage(c)) Enforcer.usedMin(c, k) else -1L))
        }
        return JSONObject().put("active", cur != null).put("activeLabel", cur?.label() ?: "")
            .put("until", Store.p(c).getLong("until", 0)).put("report", Enforcer.report(c))
            .put("launcher", Enforcer.isDefaultLauncher(c)).put("protect", Enforcer.isOwner(c) || Enforcer.isAdmin(c))
            .put("usage", Enforcer.hasUsage(c)).put("sch", sch).put("lim", lim)
            .put("exc", JSONArray(Store.exc(c).sorted())).toString()
    }

    /** null = 성공, 문자열 = 사용자에게 보여줄 메시지 */
    private fun handle(call: MethodCall): Any? {
        val c = this
        fun str(k: String) = call.argument<String>(k)!!
        fun int(k: String) = call.argument<Number>(k)!!.toInt()
        fun num(k: String) = call.argument<Number>(k)!!.toLong()
        val day = 24 * 3600000L
        when (call.method) {
            "state" -> return state()
            "apps" -> return JSONArray(Enforcer.launchable(c).filter { it.pkg !in Enforcer.always(c) }
                .map { JSONObject().put("pkg", it.pkg).put("label", it.label) }).toString()
            "addSchedule" -> {
                val days = call.argument<List<Int>>("days")!!.toSet()
                val allowed = call.argument<List<String>>("allowed")!!.toSet()
                var la: Double? = null; var ln: Double? = null
                if (call.argument<Boolean>("place") == true) {
                    val l = Enforcer.lastLoc(c) ?: return "위치 권한을 허용하고 위치를 켠 뒤 다시 시도하세요"
                    la = l.latitude; ln = l.longitude
                }
                Store.save(c, Store.load(c).also { it.add(Sch(days, int("start"), int("end"), allowed, 0, la, ln)) })
            }
            "toggleDelSchedule" -> {
                val l = Store.load(c); val x = int("i"); val s = l[x]
                l[x] = s.copy(delAt = if (s.delAt > 0) 0L else System.currentTimeMillis() + day); Store.save(c, l)
            }
            "deleteSchedule" -> { val l = Store.load(c); l.removeAt(int("i")); Store.save(c, l) }
            "setLimit" -> {
                val m = Store.limits(c); val pkg = str("pkg"); val mins = int("min"); val old = m[pkg]
                if (old != null && mins > old.first) return "한도는 늘릴 수 없어요. 해제 예약(24시간 후) 뒤 다시 설정하세요"
                m[pkg] = Pair(mins, 0L); Store.setLimits(c, m); Enforcer.sync(c)
            }
            "toggleDelLimit" -> {
                val m = Store.limits(c); val pkg = str("pkg"); val v = m[pkg]
                if (v != null) { m[pkg] = Pair(v.first, if (v.second > 0) 0L else System.currentTimeMillis() + day); Store.setLimits(c, m); Enforcer.sync(c) }
            }
            "removeLimit" -> { val m = Store.limits(c); m.remove(str("pkg")); Store.setLimits(c, m); Enforcer.sync(c) }
            "addException" -> {
                val ms = num("ms")
                if (call.argument<Boolean>("force") != true && ms < System.currentTimeMillis() + day) return "예외 날짜는 24시간 이후부터 지정할 수 있어요"
                Store.setExc(c, Store.exc(c) + Enforcer.dayKey(ms))
            }
            "removeException" -> Store.setExc(c, Store.exc(c) - str("k"))
            "unlock" -> Enforcer.adminUnlock(c, num("ms"))
            "relock" -> Enforcer.relock(c)
            "pass" -> { Store.p(c).edit().putLong("uninstallOk", System.currentTimeMillis() + 600000).apply(); return "10분 동안 설정에서 앱 정보를 열 수 있어요" }
            "resetLog" -> Store.p(c).edit().remove("log").putLong("inst", System.currentTimeMillis()).apply()
            "uninstall" -> Enforcer.uninstall(c)
            "openAccessibility" -> startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            "openUsage" -> startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
            "openHome" -> startActivity(Intent(Settings.ACTION_HOME_SETTINGS))
            "enableAdmin" -> startActivity(Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN)
                .putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, ComponentName(c, AdminReceiver::class.java))
                .putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION, "앱 삭제 방지에 사용돼요"))
        }
        return null
    }
}
