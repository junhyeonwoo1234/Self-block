SelfBlock - GitHub ZIP 업로드용

[업로드 방법]
1. flutlab.io 로그인 -> Workspace -> "+ Project" (또는 Welcome 화면의 Upload/Import)
2. "Upload .zip" 선택 -> 이 zip 파일 선택 (zip 최상위에 pubspec.yaml 이 있음)
3. 프로젝트가 열리면 Pub get -> Build Project(Android APK) -> APK 다운로드/QR로 설치

[설치 후 설정]
- 홈 앱을 "셀프블록"으로 지정 / 기기 관리자 켜기 / 접근성 켜기 / 사용 기록 접근 허용

[Gradle 오류가 나면]
- GitHub 새 프로젝트의 android/ 의 settings.gradle(.kts), build.gradle(.kts),
  app/build.gradle(.kts), gradle.properties 로 교체하되
  android/app/src/main 안의 파일(AndroidManifest.xml, kotlin/, res/)은 이 프로젝트 것을 유지.
- 패키지명(namespace/applicationId)은 com.example.selfblock 으로 맞출 것.

[Device Owner(선택)]
adb shell dpm set-device-owner com.example.selfblock/com.example.selfblock.AdminReceiver
